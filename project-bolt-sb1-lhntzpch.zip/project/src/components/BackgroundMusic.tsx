import React, { useEffect, useRef } from 'react';

export const BackgroundMusic = () => {
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.5; // Set volume to 50%
      audioRef.current.play().catch(error => {
        console.log('Audio autoplay failed:', error);
      });
    }
  }, []);

  return (
    <audio
      ref={audioRef}
      src="https://files.catbox.moe/9070vl.mp3"
      loop
    />
  );
};